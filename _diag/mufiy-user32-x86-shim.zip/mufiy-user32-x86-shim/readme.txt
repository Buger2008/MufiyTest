﻿32 位 user32 入口点转发 DLL —— Mufiy win-x86 兼容补丁
=======================================================

一、这是干什么的
----------------
Mufiy.Platform.Desktop.Provider 的窗口层声明了这两个 P/Invoke：

    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    SetWindowLongPtr / GetWindowLongPtr

但这两个导出**只存在于 64 位 user32.dll**。实测导出表：

    System32\user32.dll  (x64)  → SetWindowLongA/W、SetWindowLongPtrA/W
    SysWOW64\user32.dll  (x86)  → 只有 SetWindowLongA/W（没有 Ptr 版本）

所以 32 位进程里 Mufiy.Window..ctor() 一调用就抛
    System.EntryPointNotFoundException:
        Unable to find an entry point named 'SetWindowLongPtr' in DLL 'user32.dll'.
这与 NativeAOT 无关：关掉 AOT 的 win-x86 一样崩；Mufiy 0.0.1-Beta9 一样崩。
（注意 SetWindowLongPtr 声明带 CharSet=Unicode 且未设 ExactSpelling，运行时先探测
  SetWindowLongPtrW、再探测裸名 SetWindowLongPtr，两个在 32 位都不存在。）


二、包里有什么
--------------
    user32.x86.def              转发表源文件（唯一的事实来源，改这个）
    mufiy.user32.x86.dll        预编译产物（x86，约 2.5 KB，纯转发表、无代码）
    build.cmd                   一键重建（自动用 vswhere 找 VS 的 x86 link.exe）
    Win32EntryPointShim.cs      托管侧：把 user32.dll 的解析重定向到上面那个 DLL
    readme.txt                  本文件


三、怎么重建
------------
双击 build.cmd 即可（只需要 VS 的 C++ 生成工具，只要 link.exe、不要 cl.exe）。

如果脚本报错，手工执行这一行也完全等价：

    "<VS>\VC\Tools\MSVC\<版本>\bin\Hostx64\x86\link.exe" ^
        /nologo /dll /noentry /machine:x86 ^
        /def:user32.x86.def /out:mufiy.user32.x86.dll

本机验证过的例子：
    "D:\Program\VS2026\Main\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x86\link.exe"


四、怎么用到自己的工程
----------------------
1) 把 mufiy.user32.x86.dll 放到 exe 同目录（只对 win-x86 目标需要）。
   csproj 里：

    <ItemGroup Condition="'$(RuntimeIdentifier)' == 'win-x86'">
      <!-- Link 不能省：否则 MSBuild 会保留 Native\ 子目录，运行时按程序目录找不到 -->
      <None Include="Native\mufiy.user32.x86.dll" Link="mufiy.user32.x86.dll">
        <CopyToOutputDirectory>PreserveNewest</CopyToOutputDirectory>
      </None>
    </ItemGroup>

2) 把 Win32EntryPointShim.cs 加进工程，并在 Main 的第一行调用：

    Win32EntryPointShim.Register();

   必须在任何窗口构造之前执行（即早于 MufiyApp.Run()）。
   x64 / arm64 上它是空操作，解析路径与打补丁前完全一致。

3) 完成。原理：NativeLibrary.SetDllImportResolver 只能重定向**库名**、改不了入口点名，
   所以转发 DLL 必须补齐该程序集用到的**全部 15 个 user32 入口点**，否则重定向之后
   其它 user32 调用反而找不到。非 Ptr 的 13 个按真实 user32 的 A/W 变体 1:1 转发，
   保证「探测 W → A → 裸名」的顺序与真实 user32 一致，行为零差异。


五、限制与善后
--------------
* 只对 32 位进程有意义；64 位下 user32 本来就有 Ptr 版本。
* 只覆盖已发现的入口点。若框架日后调用别的 64 位专属 API，需要往 .def 里继续加。
* **这是过渡方案**：Mufiy 上游把窗口创建路径改成按 IntPtr.Size 选择非 Ptr 版本之后，
  本包连同工程里的托管侧补丁都可以整块删掉。
